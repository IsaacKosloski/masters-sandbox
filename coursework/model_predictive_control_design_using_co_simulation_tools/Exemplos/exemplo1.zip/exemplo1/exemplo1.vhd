library ieee;
library ieee_proposed; -- biblioteca espec�fica para opera��es matriciais
                       -- Esta biblioteca ser� reconhecida se compilar os arquivos compile.mti

use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;

use ieee_proposed.real_matrix_pkg.all; -- define o tipo de dedado utilizado nas opera��es matriciais

entity exemplo1 is
  port( clk, rst : in std_logic);

end entity;

architecture m1 of exemplo1 is
	signal a: real_matrix (0 to 3, 0 to 1):=zeros(4,2);  -- define a dimens�o das matrizes, neste caso 4x2
  signal b: real_matrix (0 to 1, 0 to 2); -- matriz de dimens�o 2x3
  signal c: real_matrix (0 to 3, 0 to 2);
  
  begin

process(clk,rst)
  
  begin 
    
  If (rst = '1') then -- quando rst = 1 carrega os valores da matriz
a <= ((1.0, 6.0),(4.0, 3.0),(7.0, 1.0),(2.0, 5.0));

b <= (( 2.0, 0.5, 3.0), (7.0, 1.0, 0.0));

elsif (clk'event and clk = '1') then -- quando rst = 0 e ocorrer um evento de subida, realiza-se a opera��o

    c <= a * b; -- Matrix multiply
    
  end if;
  
end process;
    
end architecture;