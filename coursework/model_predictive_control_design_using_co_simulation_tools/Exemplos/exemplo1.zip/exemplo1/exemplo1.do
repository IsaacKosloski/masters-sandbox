-- Registradores Entrada Paralela Saida sSerial
-- Prof. Edson Antonio Batista
-- MPC
vcom exemplo1.vhd
vsim work.exemplo1


add wave a
add wave b
add wave c
add wave clk 
add wave rst



force clk 0 0, 1 50 -r 100
force rst 1
run 100

force rst 0
run 400

